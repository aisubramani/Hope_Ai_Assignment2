/* script.js - Client Side Camera Version */
document.addEventListener('DOMContentLoaded', () => {
    const videoElement = document.getElementById('input_video');
    const canvasElement = document.getElementById('output_canvas');
    const canvasCtx = canvasElement.getContext('2d');
    const gestureResult = document.getElementById('gestureresult');
    const historyList = document.getElementById('historyList');
    const btnLeft = document.getElementById('btnLeft');
    const btnRight = document.getElementById('btnRight');
    const voiceToggle = document.getElementById('voiceToggle');
    const loadingOverlay = document.getElementById('loadingOverlay');

    let currentMode = 'left';
    let lastPrediction = "";
    let lastSpokenTime = 0;

    // Audio Unlock Logic
    const synth = window.speechSynthesis;
    let audioUnlocked = false;
    document.body.addEventListener('click', () => {
        if (!audioUnlocked) {
            const utterance = new SpeechSynthesisUtterance(" ");
            utterance.volume = 0;
            synth.speak(utterance);
            audioUnlocked = true;
        }
    }, { once: true });

    function speak(text) {
        if (!text || text === "nothing") return;
        const now = Date.now();
        if (text !== lastPrediction || (now - lastSpokenTime > 2000)) {
            if (voiceToggle.checked) {
                const utterance = new SpeechSynthesisUtterance(text);
                synth.speak(utterance);
            }
            if (text !== lastPrediction) addToHistory(text);
            lastPrediction = text;
            lastSpokenTime = now;
        }
    }

    function addToHistory(text) {
        const li = document.createElement('li');
        li.innerHTML = `<strong>${text}</strong> <span>${new Date().toLocaleTimeString()}</span>`;
        historyList.prepend(li);
        if (historyList.children.length > 15) historyList.removeChild(historyList.lastChild);
    }

    // landmark preprocessing (Matches Python camera.py logic)
    function preProcessLandmarks(landmarks) {
        let processed = [];
        let baseX = landmarks[0].x;
        let baseY = landmarks[0].y;

        // Relative coordinates
        for (let lm of landmarks) {
            processed.push(lm.x - baseX);
            processed.push(lm.y - baseY);
        }

        // Normalization
        let maxValue = Math.max(...processed.map(Math.abs));
        if (maxValue !== 0) {
            processed = processed.map(v => v / maxValue);
        }

        // Mirroring logic if needed (mimics other hand)
        if (currentMode === 'right') {
            for (let i = 0; i < processed.length; i += 2) {
                processed[i] = processed[i] * -1;
            }
        }

        return processed;
    }

    function onResults(results) {
        // Hide loader on first frame
        if (loadingOverlay) loadingOverlay.style.display = 'none';

        // Draw video to canvas
        canvasCtx.save();
        canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

        // Horizontal Flip (Mirrored View)
        canvasCtx.translate(canvasElement.width, 0);
        canvasCtx.scale(-1, 1);
        canvasCtx.drawImage(results.image, 0, 0, canvasElement.width, canvasElement.height);

        if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
            for (const landmarks of results.multiHandLandmarks) {
                // Draw landmarks in browser
                drawConnectors(canvasCtx, landmarks, HAND_CONNECTIONS, { color: '#00FF00', lineWidth: 5 });
                drawLandmarks(canvasCtx, landmarks, { color: '#FFFFFF', lineWidth: 2, radius: 3 });

                // Preprocess and Predict
                const processedData = preProcessLandmarks(landmarks);

                fetch('/predict', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ landmarks: processedData })
                })
                    .then(res => res.json())
                    .then(data => {
                        if (data.prediction && data.prediction !== "") {
                            gestureResult.innerText = data.prediction;
                            speak(data.prediction);
                        }
                    })
                    .catch(err => console.error("Prediction error:", err));
            }
        } else {
            gestureResult.innerText = "Wait...";
        }
        canvasCtx.restore();
    }

    const hands = new Hands({
        locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
    });

    hands.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.7,
        minTrackingConfidence: 0.5
    });

    hands.onResults(onResults);

    const camera = new Camera(videoElement, {
        onFrame: async () => {
            await hands.send({ image: videoElement });
        },
        width: 640,
        height: 480
    });
    camera.start();

    // UI Controls
    btnLeft.addEventListener('click', () => {
        currentMode = 'left';
        btnLeft.classList.add('active');
        btnRight.classList.remove('active');
    });

    btnRight.addEventListener('click', () => {
        currentMode = 'right';
        btnRight.classList.add('active');
        btnLeft.classList.remove('active');
    });
});
