from flask import Flask, render_template, Response, jsonify, request
import os
import sys
from model.keypoint_classifier import KeyPointClassifier

# Fix for Protobuf issues
os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'

app = Flask(__name__)

# Load the classifier once at startup
classifier = KeyPointClassifier()

# Load labels
labels = []
current_dir = os.path.dirname(os.path.abspath(__file__))
labels_path = os.path.join(current_dir, 'model', 'labels.txt')
try:
    with open(labels_path, 'r') as f:
        labels = [line.strip() for line in f.readlines()]
except Exception:
    labels = ["Error Loading Labels"]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/predict', methods=['POST'])
def predict():
    """Receives landmarks from the browser and returns a prediction."""
    try:
        data = request.get_json()
        landmarks = data.get('landmarks', [])
        
        if not landmarks:
            return jsonify(prediction="")

        # Predict
        res_index = classifier(landmarks)
        
        prediction = ""
        if res_index != -1 and res_index < len(labels):
            prediction = labels[res_index]
            
        return jsonify(prediction=prediction)
    except Exception as e:
        return jsonify(error=str(e)), 400

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port, debug=False)
