import cv2
import mediapipe as mp
import csv
import copy
import itertools
import os
import glob
from tqdm import tqdm

def calc_landmark_list(image, landmarks):
    image_width, image_height = image.shape[1], image.shape[0]
    landmark_point = []

    for _, landmark in enumerate(landmarks.landmark):
        landmark_x = min(int(landmark.x * image_width), image_width - 1)
        landmark_y = min(int(landmark.y * image_height), image_height - 1)
        landmark_point.append([landmark_x, landmark_y])

    return landmark_point

def pre_process_landmark(landmark_list):
    temp_landmark_list = copy.deepcopy(landmark_list)

    # Convert to relative coordinates
    base_x, base_y = 0, 0
    for index, landmark_point in enumerate(temp_landmark_list):
        if index == 0:
            base_x, base_y = landmark_point[0], landmark_point[1]

        temp_landmark_list[index][0] = temp_landmark_list[index][0] - base_x
        temp_landmark_list[index][1] = temp_landmark_list[index][1] - base_y

    # Convert to a one-dimensional list
    temp_landmark_list = list(
        itertools.chain.from_iterable(temp_landmark_list))

    # Normalization
    max_value = max(list(map(abs, temp_landmark_list))) if temp_landmark_list else 0
    
    def normalize_(n):
        return n / max_value if max_value != 0 else 0

    temp_landmark_list = list(map(normalize_, temp_landmark_list))

    return temp_landmark_list

def main():
    dataset_dir = r"c:\Users\15016\Desktop\HopeAi\python\Week14_ChatGPT_API_Adv_GenAi\ss_project\model\dataset\asl_alphabet_train"
    csv_path = r"c:\Users\15016\Desktop\HopeAi\python\Week14_ChatGPT_API_Adv_GenAi\ss_project\model\keypoint.csv"
    
    # Initialize MediaPipe
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(
        static_image_mode=True, # Important for independent images
        max_num_hands=1,
        min_detection_confidence=0.5,
    )

    # Get classes
    classes = sorted([d for d in os.listdir(dataset_dir) if os.path.isdir(os.path.join(dataset_dir, d))])
    print(f"Found {len(classes)} classes: {classes}")
    
    # Save labels mapping
    labels_path = r"c:\Users\15016\Desktop\HopeAi\python\Week14_ChatGPT_API_Adv_GenAi\ss_project\model\labels.txt"
    with open(labels_path, 'w') as f:
        for cls in classes:
            f.write(f"{cls}\n")
    
    # Prepare CSV
    with open(csv_path, 'w', newline="") as f:
        pass # Clear file

    IMAGES_PER_CLASS = 1000 # Increased from 50 to 1000 for better accuracy
    
    print(f"Processing images... (Limit: {IMAGES_PER_CLASS} per class)")
    
    total_processed = 0

    for idx, class_name in enumerate(classes):
        class_path = os.path.join(dataset_dir, class_name)
        image_files = glob.glob(os.path.join(class_path, "*.jpg")) + glob.glob(os.path.join(class_path, "*.png"))
        
        # Limit processing
        image_files = image_files[:IMAGES_PER_CLASS]
        
        print(f"Processing Class {idx}: {class_name} ({len(image_files)} images)")
        
        for image_path in image_files:
            image = cv2.imread(image_path)
            if image is None:
                continue
                
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            results = hands.process(image)
            
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    # Conversion and normalization
                    landmark_list = calc_landmark_list(image, hand_landmarks)
                    pre_processed_landmark_list = pre_process_landmark(landmark_list)
                    
                    # Write to CSV
                    with open(csv_path, 'a', newline="") as f:
                        writer = csv.writer(f)
                        writer.writerow([idx, *pre_processed_landmark_list])
                        total_processed += 1
                        
    print(f"Finished processing. Total samples collected: {total_processed}")
    print(f"Saved to {csv_path}")

if __name__ == "__main__":
    main()
