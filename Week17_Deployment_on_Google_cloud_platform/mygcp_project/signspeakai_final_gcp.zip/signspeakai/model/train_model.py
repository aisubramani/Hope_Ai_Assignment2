import csv
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
import pandas as pd
import os

def main():
    dataset_path = r'c:\Users\15016\Desktop\HopeAi\python\Week14_ChatGPT_API_Adv_GenAi\ss_project\model\keypoint.csv'
    model_save_path = r'c:\Users\15016\Desktop\HopeAi\python\Week14_ChatGPT_API_Adv_GenAi\ss_project\model\keypoint_classifier.keras'
    tflite_save_path = r'c:\Users\15016\Desktop\HopeAi\python\Week14_ChatGPT_API_Adv_GenAi\ss_project\model\keypoint_classifier.tflite'
    
    if not os.path.exists(dataset_path):
        print("No dataset found. Run collect_data.py first.")
        return

    # Load dataset
    # Expect first column to be label
    try:
        df = pd.read_csv(dataset_path, header=None)
    except Exception as e:
        print(f"Error reading dataset: {e}")
        return

    X = df.iloc[:, 1:].values
    y = df.iloc[:, 0].values
    
    # Check number of classes
    # Use max(y) + 1 because some classes might have 0 samples (e.g. 'nothing')
    # but we need the output layer to cover the highest label index.
    num_classes = int(np.max(y) + 1)
    print(f"Found {len(np.unique(y))} unique classes. Max label: {np.max(y)}. Setting output size to {num_classes}")

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Model definition
    model = tf.keras.models.Sequential([
        tf.keras.layers.Input((42, )),
        
        # Increased capacity
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dropout(0.2),
        
        tf.keras.layers.Dense(64, activation='relu'),
        tf.keras.layers.Dropout(0.2),
        
        tf.keras.layers.Dense(32, activation='relu'),
        
        tf.keras.layers.Dense(num_classes, activation='softmax')
    ])

    model.summary()

    # Model checkpoint
    cp_callback = tf.keras.callbacks.ModelCheckpoint(
        model_save_path, verbose=1, save_weights_only=False)

    # Compilation
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )

    # Training
    model.fit(
        X_train,
        y_train,
        epochs=100,
        batch_size=128,
        validation_data=(X_test, y_test),
        callbacks=[cp_callback]
    )

    # Eval
    val_loss, val_acc = model.evaluate(X_test, y_test, batch_size=128)
    print(f"Validation loss: {val_loss}, accuracy: {val_acc}")
    
    # Save inference model
    model.save(model_save_path)
    
    # Save as TFLite
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    tflite_model = converter.convert()
    with open(tflite_save_path, 'wb') as f:
        f.write(tflite_model)
    print(f"Saved TFLite model to {tflite_save_path}")

if __name__ == '__main__':
    main()
