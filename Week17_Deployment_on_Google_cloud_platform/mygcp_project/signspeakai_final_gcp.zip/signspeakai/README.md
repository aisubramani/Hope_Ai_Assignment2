# VoiceGestures: AI Sign Language to Speech

A real-time AI application that translates hand gestures into spoken voice using Computer Vision and Deep Learning.

## Features
- **Real-time Hand Tracking**: Uses MediaPipe to track hand landmarks.
- **Deep Learning Classifier**: Uses a TensorFlow/Keras Neural Network to classify gestures.
- **Text-to-Speech**: Converts recognized gestures into natural-sounding speech.
- **Modern UI**: A beautiful, dark-mode web interface.

## Setup

1. **Install Dependencies**:
   Open a terminal in this directory and run:
   ```bash
   pip install -r requirements.txt
   ```

   **Note for Windows Users (Python 3.11):**
   The AI libraries used (MediaPipe/TensorFlow) work best with Python 3.11.
   If you have **Conda**, please use the recommended environment:
   ```bash
   conda activate ssai311
   pip install -r requirements.txt
   ```

2. **Data Collection (Crucial First Step)**:
   Since this system uses Deep Learning, it needs to learn YOUR specific gestures.
   
   - Run the collection script:
     ```bash
     python model/collect_data.py
     ```
   - A camera window will open.
   - **Press '0' on your keyboard** to save the current hand pose as "Class 0" (e.g., Hello).
   - **Press '1'** for "Class 1" (e.g., Yes).
   - **Press '2'** for "Class 2" (e.g., No).
   - **Press '3'** for "Class 3" (e.g., I Love You).
   - Collect about 200-300 frames per gesture (hold the key down while moving your hand slightly).
   - Press 'q' to quit.

3. **Train the Model**:
   Once data is collected, train the neural network:
   ```bash
   python model/train_model.py
   ```
   This will generate `model/keypoint_classifier.tflite`.

4. **Run the Application**:
   Start the main interface:
   ```bash
   python app.py
   ```
   - Open your browser to `http://127.0.0.1:5000`.
   - Enable "Speech" in the top right.
   - Perform gestures and hear them spoken!

## Customization
- To change the words associated with gestures, edit `camera.py`:
  ```python
  self.keypoint_labels = ["Hello", "Yes", "No", "Nice to meet you"] 
  ```
  Ensure the order matches the IDs you used during collection (0, 1, 2, ...).
