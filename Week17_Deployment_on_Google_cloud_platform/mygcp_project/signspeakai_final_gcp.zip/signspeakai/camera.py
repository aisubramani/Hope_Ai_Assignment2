import cv2
import os
import mediapipe as mp
import copy
import itertools
from model.keypoint_classifier import KeyPointClassifier

# Direct internal imports for stability
from mediapipe.python.solutions import hands as mp_hands
from mediapipe.python.solutions import drawing_utils as mp_drawing

class VideoCamera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(0)
        # Try to disable auto-focus (0 = off, 1 = on)
        self.video.set(cv2.CAP_PROP_AUTOFOCUS, 0) 
        
        self.mp_hands = mp_hands
        self.hands = self.mp_hands.Hands(
            max_num_hands=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.5,
        )
        
        self.keypoint_classifier = KeyPointClassifier()
        
        # Load labels dynamically
        self.keypoint_labels = []
        # Dynamic path relative to this file
        current_dir = os.path.dirname(os.path.abspath(__file__))
        labels_path = os.path.join(current_dir, 'model', 'labels.txt')
        try:
            with open(labels_path, 'r') as f:
                self.keypoint_labels = [line.strip() for line in f.readlines()]
        except FileNotFoundError:
            # Fallback
            self.keypoint_labels = ["No Labels Found"]
            print("labels.txt not found. Please run convert_dataset.py or collect_data.py")

        self.latest_prediction = ""
        self.mirror_hand_mode = False # False = Normal (Left?), True = Mirrored (Right?)

    def __del__(self):
        self.video.release()

    def calc_landmark_list(self, image, landmarks):
        image_width, image_height = image.shape[1], image.shape[0]
        landmark_point = []

        for _, landmark in enumerate(landmarks.landmark):
            landmark_x = min(int(landmark.x * image_width), image_width - 1)
            landmark_y = min(int(landmark.y * image_height), image_height - 1)
            landmark_point.append([landmark_x, landmark_y])

        return landmark_point

    def pre_process_landmark(self, landmark_list):
        temp_landmark_list = copy.deepcopy(landmark_list)

        # Convert to relative coordinates
        base_x, base_y = 0, 0
        for index, landmark_point in enumerate(temp_landmark_list):
            if index == 0:
                base_x, base_y = landmark_point[0], landmark_point[1]

            temp_landmark_list[index][0] = temp_landmark_list[index][0] - base_x
            temp_landmark_list[index][1] = temp_landmark_list[index][1] - base_y

        # Convert to a one-dimensional list
        temp_landmark_list = list(
            itertools.chain.from_iterable(temp_landmark_list))

        # Normalization
        max_value = max(list(map(abs, temp_landmark_list))) if temp_landmark_list else 0
        
        def normalize_(n):
            return n / max_value if max_value != 0 else 0

        temp_landmark_list = list(map(normalize_, temp_landmark_list))

        return temp_landmark_list

    def get_frame(self):
        success, image = self.video.read()
        if not success:
            # Try to reconnect once
            self.video.release()
            self.video = cv2.VideoCapture(0)
            success, image = self.video.read()
            if not success:
                return None, ""

        image = cv2.flip(image, 1)
        debug_image = copy.deepcopy(image)
        
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image.flags.writeable = False
        results = self.hands.process(image)
        image.flags.writeable = True
        
        prediction_text = ""

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                landmark_list = self.calc_landmark_list(debug_image, hand_landmarks)
                pre_processed_landmark_list = self.pre_process_landmark(landmark_list)

                # Handedness check
                # We will use a manual toggle instead of automatic detection as requested.
                # self.mirror_hand_mode will be controlled from the UI.
                if self.mirror_hand_mode:
                     # Flip X coords to mimic the other hand
                     for i in range(0, len(pre_processed_landmark_list), 2):
                         pre_processed_landmark_list[i] = pre_processed_landmark_list[i] * -1

                # Predict
                hand_sign_id = self.keypoint_classifier(pre_processed_landmark_list)
                
                if hand_sign_id != -1 and hand_sign_id < len(self.keypoint_labels):
                    prediction_text = self.keypoint_labels[hand_sign_id]
                else:
                    prediction_text = ""
                
                # Draw
                mp_drawing.draw_landmarks(
                    debug_image,
                    hand_landmarks,
                    self.mp_hands.HAND_CONNECTIONS
                )
                
                # Draw Text
                cv2.putText(debug_image, prediction_text, (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 0), 4, cv2.LINE_AA)
                cv2.putText(debug_image, prediction_text, (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2, cv2.LINE_AA)

        self.latest_prediction = prediction_text
        
        ret, jpeg = cv2.imencode('.jpg', debug_image)
        return jpeg.tobytes(), prediction_text
