# Step 1: Set the project ID (Already set to directed-seeker-482311-h0)
$PROJECT_ID = "directed-seeker-482311-h0"
$REGION = "us-central1"
$SERVICE_NAME = "signspeakai"

Write-Host "🚀 Starting Deployment for $SERVICE_NAME..." -ForegroundColor Cyan

# Step 2: Build the image using Cloud Build
Write-Host "📦 Building container image..." -ForegroundColor Yellow
gcloud builds submit --tag gcr.io/$PROJECT_ID/$SERVICE_NAME

# Step 3: Deploy to Cloud Run
Write-Host "🌐 Deploying to Cloud Run..." -ForegroundColor Yellow
gcloud run deploy $SERVICE_NAME `
    --image gcr.io/$PROJECT_ID/$SERVICE_NAME `
    --platform managed `
    --region $REGION `
    --allow-unauthenticated `
    --memory 2Gi `
    --cpu 1

Write-Host "✅ Deployment Complete!" -ForegroundColor Green
