from django.shortcuts import render
import os
from django.conf import settings
# from django.core.files.storage import default_storage  <-- No longer needed
# from django.core.files.base import ContentFile       <-- No longer needed

import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image
import numpy as np
import cv2
import base64
from io import BytesIO

# device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# classes & friendly names
classes = ['glioma_tumor', 'meningioma_tumor', 'no_tumor', 'pituitary_tumor']
friendly_names = {
    "glioma_tumor": "Glioma Tumor",
    "meningioma_tumor": "Meningioma Tumor",
    "no_tumor": "No Tumor",
    "pituitary_tumor": "Pituitary Tumor"
}

# transforms
val_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225])
])

# model path (inside app/model/)
MODEL_REL_PATH = os.path.join('braintumorvisionai', 'model', 'best_mobilenetv3_mri_final.pth')
MODEL_ABS_PATH = os.path.join(settings.BASE_DIR, MODEL_REL_PATH)

# load model
def load_model():
    model = models.mobilenet_v3_large(weights=None)

    # adjust classifier
    try:
        in_features = model.classifier[-1].in_features
        model.classifier[-1] = nn.Linear(in_features, 4)
    except:
        model.classifier[3] = nn.Linear(model.classifier[3].in_features, 4)

    model.load_state_dict(torch.load(MODEL_ABS_PATH, map_location=device))
    model.to(device)
    model.eval()
    return model

model = load_model()

# hooks
gradients = []
activations = []

def save_gradient(grad):
    gradients.append(grad)

# register hooks on last conv
target_layer = model.features[-1]
target_layer.register_forward_hook(lambda m, i, o: activations.append(o))
target_layer.register_full_backward_hook(lambda m, gi, go: save_gradient(go[0]))

def to_base64(img_pil):
    """Converts a PIL Image to a Base64 string"""
    buffered = BytesIO()
    img_pil.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode('utf-8')

def predict_with_heatmap(image_file):

    gradients.clear()
    activations.clear()

    # Open image directly from the uploaded file (BytesIO)
    img = Image.open(image_file).convert("RGB")
    
    # Preprocess
    processed = val_transform(img).unsqueeze(0).to(device)

    # Inferences
    outputs = model(processed)
    probs = torch.softmax(outputs, dim=1)
    conf, pred = torch.max(probs, 1)

    class_name = classes[pred.item()]
    readable = friendly_names[class_name]
    confidence = conf.item() * 100
    status = "NO" if class_name == "no_tumor" else "YES"

    # backward for gradcam
    model.zero_grad()
    outputs[0, pred.item()].backward()

    grads = gradients[-1].cpu().data.numpy()[0]   # C,H,W
    acts = activations[-1].cpu().data.numpy()[0]  # C,H,W

    weights = np.mean(grads, axis=(1, 2))
    cam = np.zeros(acts.shape[1:], dtype=np.float32)

    for i, w in enumerate(weights):
        cam += w * acts[i]

    cam = np.maximum(cam, 0)
    cam = cv2.resize(cam, (img.size[0], img.size[1]))
    cam = (cam - cam.min()) / cam.max() if cam.max() != 0 else cam

    heatmap = cv2.applyColorMap(np.uint8(255 - cam * 255), cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)

    original_np = np.array(img)
    overlay = cv2.addWeighted(original_np, 0.55, heatmap, 0.45, 0)

    # CONVERT TO BASE64 (IN MEMORY)
    original_b64 = to_base64(img)
    heatmap_pil = Image.fromarray(overlay)
    heatmap_b64 = to_base64(heatmap_pil)

    return original_b64, heatmap_b64, status, readable, round(confidence, 2)


def brain_home(request):
    context = {}

    if request.method == "POST" and request.FILES.get("mri"):
        uploaded = request.FILES["mri"]
        
        # Pass the uploaded file directly to the helper
        original_b64, heatmap_b64, status, result, confidence = predict_with_heatmap(uploaded)

        context = {
            "result": result,
            "status": status,
            "confidence": confidence,
            "original_b64": original_b64,  # Passing base64 strings
            "heatmap_b64": heatmap_b64,
        }

    return render(request, "braintumorvisionai/brain_home.html", context)

