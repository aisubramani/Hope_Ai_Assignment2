import json
import time
import os
from backend.retrieval import RetrievalEngine
from backend.guardrails import Guardrails
from backend.generation import GenerationEngine
from backend.confidence import ConfidenceScorer
from evaluation.metrics import calculate_metrics

def run_eval_silent(engines=None):
    # Determine absolute path to test_cases.json
    base_dir = os.path.dirname(__file__)
    test_file = os.path.join(base_dir, "test_cases.json")
    
    if not os.path.exists(test_file):
        print(f"Error: Test file not found at {test_file}")
        return None
        
    with open(test_file, "r") as f:
        tests = json.load(f)
    
    # Use existing engines if provided, otherwise initialize new ones
    if engines:
        r, g, gen, s = engines
    else:
        r, g, gen, s = RetrievalEngine(), Guardrails(), GenerationEngine(), ConfidenceScorer()
        
    results = []
    
    for test in tests:
        query = test["query"]
        start = time.time()
        try:
            # Respect the passed depth parameter
            ev = r.retrieve(query)
            valid = g.validate_evidence(query, ev)
            if not valid:
                ans, conf = g.get_refusal(), 0.0
            else:
                ans = gen.generate_answer(query, ev)
                conf = s.calculate_confidence(query, ev)
            results.append({
                "query": query, 
                "answer": ans, 
                "confidence": conf, 
                "latency": time.time()-start, 
                "refused": not valid, 
                "expected_grounding": test["expected_grounding"]
            })
        except Exception as e:
            print(f"Test Case Failed ({query}): {e}")
            continue
            
    return calculate_metrics(results) if results else None
