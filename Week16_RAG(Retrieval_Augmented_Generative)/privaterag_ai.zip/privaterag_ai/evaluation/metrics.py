from typing import List, Dict

def calculate_metrics(results: List[Dict]) -> Dict:
    total = len(results)
    if total == 0: return {}
    
    correct_refusals = 0
    grounded_answers = 0
    hallucinations = 0
    missed_answers = 0
    
    # Track cases where grounding was expected vs not
    total_expected = sum(1 for r in results if r["expected_grounding"])
    total_out_of_scope = total - total_expected
    
    for res in results:
        is_grounded = res["expected_grounding"]
        did_refuse = res["refused"]
        
        if not is_grounded:
            if did_refuse:
                correct_refusals += 1
            else:
                hallucinations += 1
        else:
            if not did_refuse:
                grounded_answers += 1
            else:
                missed_answers += 1
                
    # Confidence should target answered questions specifically
    answered_conf = [r['confidence'] for r in results if not r['refused']]
    avg_conf = sum(answered_conf) / len(answered_conf) if answered_conf else 0
            
    return {
        "total_cases": total,
        "accuracy": round((grounded_answers + correct_refusals) / total, 2),
        "grounded_rate": round(grounded_answers / total_expected, 2) if total_expected > 0 else 0,
        "refusal_precision": round(correct_refusals / total_out_of_scope, 2) if total_out_of_scope > 0 else 0,
        "hallucinations": hallucinations,
        "avg_confidence": round(avg_conf, 1)
    }
