import json
import os
import re
from typing import List, Set
from collections import Counter
from langchain_ollama import OllamaLLM
from langchain_core.prompts import PromptTemplate
from langchain_core.documents import Document

class QueryNormalizationEngine:
    def __init__(self, model_name: str = "llama3"):
        # Optimize: Set num_predict to limit generation to short query length (approx 50 words)
        self.llm = OllamaLLM(model=model_name, temperature=0, num_predict=64)
        self.vocab_path = "data/vocabulary.json"
        
        # Stop words to exclude from vocabulary extraction
        self.stop_words = {
            "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "of", "with", "by", 
            "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "do", "does", "did",
            "this", "that", "these", "those", "it", "its", "from", "as", "if", "when", "where", "which",
            "who", "what", "why", "how", "all", "any", "some", "no", "not", "only", "own", "other", "so",
            "than", "then", "too", "very", "can", "will", "just", "should", "now"
        }

    def extract_vocabulary(self, docs: List[Document]) -> List[str]:
        """Extracts top 150 domain-specific terms from documents."""
        all_text = " ".join([d.page_content.lower() for d in docs])
        # Simple tokenization: remove punctuation and split
        words = re.findall(r'\b[a-z]{3,}\b', all_text)
        
        # Filter stop words
        filtered_words = [w for w in words if w not in self.stop_words]
        
        # Count frequencies
        counter = Counter(filtered_words)
        
        # Optimize: Get top 150 most common substantive words (reduced from 300 for speed)
        top_vocab = [word for word, count in counter.most_common(150)]
        return top_vocab

    def save_vocabulary(self, vocabulary: List[str]):
        """Persists vocabulary to disk."""
        os.makedirs(os.path.dirname(self.vocab_path), exist_ok=True)
        with open(self.vocab_path, "w") as f:
            json.dump(vocabulary, f)

    def load_vocabulary(self) -> List[str]:
        """Loads vocabulary from disk."""
        if os.path.exists(self.vocab_path):
            with open(self.vocab_path, "r") as f:
                return json.load(f)
        return []

    def normalize_query(self, query: str, vocabulary: List[str]) -> str:
        """
        Deterministically normalizes the user query.
        OPTIMIZED FOR SPEED.
        """
        
        # Limit vocabulary context to first 1000 chars to save input tokens
        vocab_str = ", ".join(vocabulary)[:1000] if vocabulary else "None"

        # Ultra-concise prompt for lower latency
        template = """Rewrite user query to align with vocab: [{vocab_str}].
Fix spelling. Use precise vocab terms. Preserve intent.
If gibberish, output: REFUSE_QUERY.
Query: {query}
Rewritten:"""
        
        prompt = PromptTemplate.from_template(template)
        chain = prompt | self.llm
        
        try:
            # We use invoke instead of stream for a single atomic string
            result = chain.invoke({
                "query": query,
                "vocab_str": vocab_str
            })
            cleaned = result.strip().strip('"')
            return cleaned
        except Exception as e:
            print(f"Normalization failed: {e}")
            return query # Fallback to original
