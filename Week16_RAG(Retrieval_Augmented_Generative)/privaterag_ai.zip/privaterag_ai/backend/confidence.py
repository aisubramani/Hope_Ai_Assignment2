from typing import List
from langchain_core.documents import Document

class ConfidenceScorer:
    def __init__(self):
        pass

    def calculate_confidence(self, query: str, context_docs: List[Document]) -> float:
        if not context_docs:
            return 0.0
            
        context_text = " ".join([d.page_content.lower() for d in context_docs])
        query_terms = [word for word in query.lower().split() if len(word) > 2]
        
        if not query_terms: return 50.0 # Base score for vague but retrieved context
        
        matches = 0
        for term in query_terms:
            if term in context_text:
                matches += 1
        
        match_ratio = matches / len(query_terms)
        
        # New Scoring Formula: 
        # 30% Evidence Volume (how many chunks)
        # 70% Semantic Overlap
        vol_score = min(len(context_docs) * 10, 30)
        sem_score = match_ratio * 70
        
        final_confidence = vol_score + sem_score
        return round(min(max(final_confidence, 5.0), 99.0), 1)
