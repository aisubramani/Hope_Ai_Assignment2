from typing import List, Dict
import os
from langchain_core.documents import Document
from .embeddings import EmbeddingEngine

class RetrievalEngine:
    def __init__(self, embedding_engine=None):
        self.embedding_engine = embedding_engine if embedding_engine else EmbeddingEngine()
        self.config = {
            "top_k": 5,
            "threshold": 0.20, 
            "lambda_mult": 0.5,
            "final_k": 3
        }

    def retrieve(self, query: str, metadata_filter: dict = None) -> List[Document]:
        vectorstore = self.embedding_engine.get_vectorstore()
        
        try:
            # 1. Primary Retrieval Pass
            docs = self._execute_search(vectorstore, query, self.config)
            
            # 2. Heuristic Re-ranking (Fix for specific identifier mismatches)
            docs = self._apply_heuristic_reranking(query, docs)
            
            # 3. Final Logging
            print(f"[AUDIT] Engine: Active | Chunks: {len(docs)}")
            return docs[:self.config["final_k"]]
            
        except Exception as e:
            print(f"[ERROR] Retrieval Failed: {e}")
            return []

    def _execute_search(self, vectorstore, query, config) -> List[Document]:
        # Perform search once with a larger pool of results for MMR/thresholding
        results_with_scores = vectorstore.similarity_search_with_relevance_scores(
            query, 
            k=config["top_k"] * 3 # Dig deeper: Increase pool for re-ranking to catch specific IDs
        )
        
        # Filter by threshold
        filtered_results = [
            doc for doc, score in results_with_scores 
            if score >= config["threshold"]
        ]
        
        return filtered_results

    def _apply_heuristic_reranking(self, query: str, docs: List[Document]) -> List[Document]:
        """
        Boosts documents that strictly contain specific identifiers mentioned in the query.
        EXCLUSIVE MODE: If matches are found, return ONLY the matching docs to prevent confusion.
        """
        import re
        
        # Detect patterns like "Figure 5", "Fig-5", "Table 2", "Section 1.1"
        # Support hyphens, dots, spaces between Number and Label
        patterns = [
            r"(figure|fig|table|tbl|section|sec)[\s\-\.]+\d+"
        ]
        
        found_identifiers = []
        for p in patterns:
            found_identifiers.extend(re.findall(p, query.lower()))
            
        if not found_identifiers:
            return docs

        # Re-construct patterns to find exact matches in text
        # We find the exact full string (e.g. "figure 5") to search for
        full_matches = []
        for p in patterns:
             full_matches.extend(re.findall(p, query.lower()))
        
        # If we just matched the keyword "figure" without number, skip
        # Wait, the regex enforces \d+.
        
        # Get the strict strings the user is asking for
        # e.g. "figure 5"
        target_strings = []
        for p in patterns:
            iterator = re.finditer(p, query.lower())
            for match in iterator:
                target_strings.append(match.group(0))

        if not target_strings:
            return docs

        boosted_docs = []
        
        for doc in docs:
            content = doc.page_content.lower()
            # Check if ANY of the target identifiers exist in the doc
            if any(ts in content for ts in target_strings):
                boosted_docs.append(doc)
        
        # EXCLUSIVE RETURN LOGIC
        # If we found documents matching the *specifically requested* Figure/Table,
        # return ONLY those documents. This prevents "Table 5" from polluting the context
        # when the user asked for "Figure 5".
        if boosted_docs:
             return boosted_docs
             
        # If NO exact identifier matches found, fall back to semantic results
        # (This is where "Table 5" might still appear if "Figure 5" is truly missing)
        return docs
