import os
from langchain_ollama import OllamaEmbeddings
from langchain_chroma import Chroma

# Disable Chroma Telemetry for Privacy/Offline spec
os.environ["ANONYMIZED_TELEMETRY"] = "False"

class EmbeddingEngine:
    def __init__(self, model_name: str = "nomic-embed-text", persist_directory: str = "vectorstore/chroma"):
        self.embeddings = OllamaEmbeddings(model=model_name)
        self.persist_directory = persist_directory
        self._vectorstore = None

    def get_vectorstore(self):
        if self._vectorstore is None:
            self._vectorstore = Chroma(
                persist_directory=self.persist_directory,
                embedding_function=self.embeddings
            )
        return self._vectorstore

    def add_documents(self, documents):
        if self._vectorstore is None:
            # First time: Initialize and save
            self._vectorstore = Chroma.from_documents(
                documents=documents,
                embedding=self.embeddings,
                persist_directory=self.persist_directory
            )
        else:
            # Subsequent times: Append to existing collection
            self._vectorstore.add_documents(documents)
            
        return self._vectorstore
    def clear_database(self):
        """Aggressive reset of the vector database for Windows stability."""
        import shutil
        import gc
        import time
        
        print(f"🧹 Commencing Deep Purge of vault: {self.persist_directory}")
        
        # 1. Release the vectorstore object to help close handles
        self._vectorstore = None
        
        # 2. Force Garbage Collection multiple times
        for _ in range(3):
            gc.collect()
            
        # 3. Attempt physical deletion
        try:
            if os.path.exists(self.persist_directory):
                # Try deleting contents first
                for item in os.listdir(self.persist_directory):
                    item_path = os.path.join(self.persist_directory, item)
                    try:
                        if os.path.isfile(item_path): os.remove(item_path)
                        elif os.path.isdir(item_path): shutil.rmtree(item_path)
                    except:
                        pass
                shutil.rmtree(self.persist_directory, ignore_errors=True)
                print("✅ Successfully cleared vault directory.")
        except Exception as e:
            print(f"⚠️ Lock detected: {e}")

        # 4. Mandatory Fresh Start: Change folder name to ensure NO old data remains
        # Even if deletion worked, we change name to be absolutely safe.
        new_folder = f"vectorstore/chroma_{int(time.time())}"
        print(f"🚀 Initializing Fresh Vault: {new_folder}")
        self.persist_directory = new_folder
        
        # 5. Build clean folder
        os.makedirs(self.persist_directory, exist_ok=True)
        return True
