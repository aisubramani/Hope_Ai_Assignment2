from typing import List
from langchain_core.documents import Document

class Guardrails:
    def __init__(self, min_evidence_chunks: int = 1):
        self.min_evidence_chunks = min_evidence_chunks
        self.refusal_message = "This information is not available in the uploaded documents."

    def validate_evidence(self, query: str, documents: List[Document]) -> bool:
        if not documents:
            return False
        return True

    def handle_vague_query(self, query: str) -> bool:
        if len(query.strip()) < 3:
            return False
        return True

    def get_refusal(self) -> str:
        return self.refusal_message
