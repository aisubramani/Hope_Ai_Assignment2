from typing import List
from langchain_ollama import OllamaLLM
from langchain_core.documents import Document
from langchain_core.prompts import PromptTemplate

class GenerationEngine:
    def __init__(self, model_name: str = "llama3"):
        # Optimize: 4k context for better document fit, 512 max output for faster return
        self.llm = OllamaLLM(model=model_name, temperature=0, num_ctx=4096, num_predict=512)
        
        with open("prompts/system_prompt.txt", "r") as f:
            self.system_prompt = f.read()

    def stream_answer(self, query: str, context_docs: List[Document]):
        context_parts = []
        for i, doc in enumerate(context_docs):
            source = doc.metadata.get('source', 'Unknown')
            context_parts.append(f"--- CONTEXT CHUNK {i+1} (Source: {source}) ---\n{doc.page_content}")
        
        context_text = "\n\n".join(context_parts)
        
        template = """{system_prompt}

### PROVIDED CONTEXT:
{context}

### USER QUESTION:
{query}

### FINAL ANSWER:"""
        
        prompt = PromptTemplate.from_template(template)
        chain = prompt | self.llm
        
        # Using stream method of LangChain Ollama
        for chunk in chain.stream({
            "system_prompt": self.system_prompt,
            "context": context_text,
            "query": query
        }):
            yield chunk

    def stream_intro(self, query: str):
        """Streams a friendly introduction or greeting response."""
        intro_template = """You are PrivateRAG AI, a professional and helpful document intelligence assistant.
Your goal is to respond to greetings or introductory questions politely while explaining your core mission: 
To provide secure, private, and high-precision document analysis without hallucinations.

TONE: Professional, friendly, and welcoming.

USER QUERY: {query}

RESPONSE:"""
        prompt = PromptTemplate.from_template(intro_template)
        chain = prompt | self.llm
        for chunk in chain.stream({"query": query}):
            yield chunk

    def generate_answer(self, query: str, context_docs: List[Document]) -> str:
        # Keep original for internal calls if needed
        return "".join(list(self.stream_answer(query, context_docs)))
