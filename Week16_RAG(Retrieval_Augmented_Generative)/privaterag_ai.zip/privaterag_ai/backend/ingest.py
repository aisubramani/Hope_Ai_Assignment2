import os
from typing import List
from .loaders import DocumentLoader
from langchain_core.documents import Document

class IngestionEngine:
    def __init__(self):
        self.loader = DocumentLoader()

    def ingest(self, paths: List[str]) -> List[Document]:
        all_docs = []
        for path in paths:
            if os.path.isfile(path):
                all_docs.extend(self.loader.load_file(path))
            elif os.path.isdir(path):
                all_docs.extend(self.loader.load_directory(path))
        return all_docs
