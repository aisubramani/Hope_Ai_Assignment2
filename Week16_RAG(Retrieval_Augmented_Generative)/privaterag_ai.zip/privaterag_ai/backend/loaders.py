import os
from typing import List
from langchain_community.document_loaders import (
    PyPDFLoader,
    Docx2txtLoader,
    CSVLoader,
    TextLoader
)
from langchain_core.documents import Document

class DocumentLoader:
    def __init__(self):
        self.supported_extensions = {
            '.pdf': PyPDFLoader,
            '.docx': Docx2txtLoader,
            '.csv': CSVLoader,
            '.txt': TextLoader,
            '.md': TextLoader
        }

    def load_file(self, file_path: str) -> List[Document]:
        ext = os.path.splitext(file_path)[1].lower()
        if ext not in self.supported_extensions:
            return []
        
        loader_cls = self.supported_extensions[ext]
        try:
            loader = loader_cls(file_path)
            docs = loader.load()
            for doc in docs:
                doc.metadata['source'] = os.path.basename(file_path)
            return docs
        except Exception:
            return []

    def load_directory(self, dir_path: str) -> List[Document]:
        documents = []
        for root, _, files in os.walk(dir_path):
            for file in files:
                full_path = os.path.join(root, file)
                documents.extend(self.load_file(full_path))
        return documents
